/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

#include "nimbelink.h"

char cmd[12];
char data[80];

char msgUART[80];
char recvdMsg[80];

char msgParse[6][20];
char * nltoken;
char * spctoken;
char * rtntoken;
char sckt[2];

uint8 counter;
uint8 recByte;

hostData GS;

/*
    Searches for string StrToFind in the string MesToSearch
    using the string.h function strstr(). If the substring 
    is found, the returned pointer to the match is compared 
    to the original substring using the function strcmp(). 
    The substring function will then return a 1 if the 
    compared value is greater than or equal to 0 and 0 if 
    the value is less than 1.
*/
uint8 substring( const char * MesToSearch , const char * StrToFind )
{
    char * result;
    result = strstr(MesToSearch,StrToFind);
    
    if( result == NULL ) return 0;
    else return 1;
    /*int val;
    val = strcmp(result,StrToFind);

    if(val>=0)
    {
        return 1;
    }
    else
    {
        return 0;
    }*/
}

/*
    Takes the message that is stored in recvdMsg and parses 
    it into separate strings, stored in the array of strings 
    msgParse. It parses the message by using the string.h 
    function strtok(). It separates the message by each new 
    line that is present and ignores new lines that only have 
    a carriage return present.
*/
void msg_parse( void )
{
    memset( msgParse , 0 , sizeof( msgParse ) );
    
    counter = 1;
    nltoken = strtok( recvdMsg , "\r\n" );
    strcpy( msgParse[0] , nltoken );
    
    while( nltoken != NULL )
    {
        nltoken = strtok( NULL , "\r\n" );
        strcpy( msgParse[counter++] , nltoken );
    }
//    nltoken = strtok( recvdMsg , "\n" );
//    
//    while( nltoken != NULL )
//    {
//        nltoken = strtok( NULL , "\n" );
//        
//        if( strcmp( nltoken , "\r" ) != 0 )
//        {
//            strcpy( msgParse[counter++] , nltoken );
//        }
//    }
}

/*
    Takes the array of strings that was previously filled 
    by msg_parse and further divides the strings by spaces 
    and by carriage returns. For now, this function is meant 
    to extract the SRING data coming from the modem, e.g. 
    "SRING: 1,17" where "1,17" would be the relavant data.
*/
void data_parse( void )
{
    spctoken = strtok( msgParse[0] , " " );
    spctoken = strtok( NULL , " " );
    strcpy( msgParse[1] , spctoken );
    
    rtntoken = strtok( msgParse[1] , "\r" );
    strcpy( msgParse[2] , rtntoken );
}

void writeCMD( char * command )
{
    strcpy( cmd , command );
}

void writeDATA( char * _data )
{
    uint8 len = strlen(data);
    
    if( len > 0 ) strcat( data , _data );
    else strcpy( data , _data );
}

/*
    Transmits data to the modem by first assembling the 
    command and data into a packet called msgUART and then 
    sending it through the UART TX line. The command is 
    separate from the data, and depending on whether or not 
    both must be sent at the same time, the packet will be 
    constructed in the appropriate manner.
*/
void NL_TX( uint8 headCmdPSNT , uint8 dataPSNT )
{
    UART_ClearTxBuffer();
    UART_ClearRxBuffer();
    UART_PC_ClearTxBuffer();
    
    memset( msgUART , 0 , sizeof( msgUART ) );
    CyDelay(10);
    memset( recvdMsg , 0 , sizeof( recvdMsg ) );
    CyDelay(10);    

    if( headCmdPSNT )
    {
        strcpy( msgUART , cmd );
        
        if( dataPSNT ) strcat( msgUART , data );
        
        UART_PutString( msgUART );
        UART_PutString( "\r" );
    } 
    else if( dataPSNT )
    {
        strcpy( msgUART , data );
        
        UART_PutString( msgUART );
        UART_PC_PutString( msgUART );
        UART_PC_PutString( "\r\n" );
        UART_PutChar( 0x1A );
    }    
}

/*
    Receives the data present in the UART RX buffer. As long 
    as there is data in the buffer, it will store each byte 
    of data in recvdMsg until the buffer is empty.
*/
void NL_RX( void )
{
    counter = 0;
    
    while( UART_GetRxBufferSize() > 0 )
    {
        recByte = UART_GetChar();
        UART_PC_PutChar(recByte);
        
        recvdMsg[counter++] = recByte;
    }
}

/*
    Clears any strings stored in cmd and data to allow new 
    commands and data to be stored.
*/
void msg_clear( void )
{
    memset( cmd , 0 , sizeof( cmd ) );
    memset( data , 0 , sizeof( data ) ); 
    CyDelay(10);
}

/*
    Sends data through the modem network socket. There are 
    6 sockets to send data through, but for now there is only 
    one in use.
*/
void NL_scktsend( uint8 socket , char * _scktdata )
{
    sprintf( sckt , "%d" , socket );
    writeCMD( SCKT_SEND );
    writeDATA( sckt );
    NL_TX(1,1);
    CyDelay(50);
    NL_RX();
    msg_clear();
    
    writeDATA( _scktdata );
    NL_TX(0,1);
    CyDelay(50);
    NL_RX();
    msg_clear();
}

/*
    Receives data through the modem network socket. The function 
    waits until bytes are received in the RX buffer to start 
    reading and recording the data.
*/
void NL_scktrecv( void )
{
    while( !(UART_GetRxBufferSize() > 0) );
    memset( recvdMsg , 0 , sizeof(recvdMsg) );
    CyDelay(10);
    NL_RX();
    msg_parse();
    data_parse();
    
    writeCMD( SCKT_RECV );
    writeDATA( msgParse[2] );
    NL_TX(1,1);
    CyDelay(50);
    NL_RX();
    msg_clear();
}

void Nimbelink_Start( void )
{
    /*ON_OFF_Write(0);
    CyDelay(1100);
    ON_OFF_Write(1);
    CyDelay(9000);*/
    
    writeCMD( "ATE0" );
    NL_TX(1,0);
    CyDelay(50);
    NL_RX();
    msg_clear();
    
    writeCMD( NET_REG_REPORT );
    NL_TX(1,0);
    CyDelay(50);
    NL_RX();
    if( substring( recvdMsg , "0,1" ) || substring( recvdMsg , "0,5" ) )
    {
        UART_PC_PutString("Connection Successful!\r\n");
    }
    
    msg_clear();
}

void Nimbelink_ConnectGS( char * port , char * IP )
{ 
    uint8 count;
    char shutdownMes[30];
    GS.portNum = port;
    GS.ipAddress = IP;
    
    writeCMD( SCKT_STATUS );
    NL_TX(1,0);
    CyDelay(50);
    NL_RX();
    msg_parse();
    msg_clear();
    
    for( count = 0 ; count < 6 ; count++ )
    {
        if( strstr( msgParse[count] , ",0" ) == NULL )
        {
            sprintf( sckt , "%d" , count + 1 );
            writeCMD( SCKT_SHUTDOWN );
            writeDATA( sckt );
            NL_TX(1,1);
            CyDelay(50);
            NL_RX();
            if( substring( recvdMsg , "OK" ) )
            {
                sprintf( shutdownMes , "\r\nSocket %s has been shut down.\r\n" , sckt );
                UART_PC_PutString(shutdownMes);
            }
            msg_clear();
        }
    }
    
    writeCMD( CONTEXT_ACTIVATE_Q );
    NL_TX(1,0);
    CyDelay(50);
    NL_RX();
    msg_clear();
    if( substring( recvdMsg , "1,0" ) )
    {
        writeCMD( CONTEXT_ACTIVATE );
        writeDATA( "1,1" );
        NL_TX(1,1);
        CyDelay(50);
        NL_RX();
        msg_clear();
        UART_ClearRxBuffer();

        
        UART_PC_PutString("\r\nActivating context...\r\n");
        
        while( !(UART_GetRxBufferSize() > 0) );        
        memset( recvdMsg , 0 , sizeof(recvdMsg) );
        CyDelay(10);
        NL_RX();
        UART_PC_PutString("\r\nDone!\r\n");
    }
    else if( substring( recvdMsg , "1,1" ) )
    {
        UART_PC_PutString("Context has been activated\r\n");
    }
    CyDelay(1);
    
    msg_clear();
    
    writeCMD( SCKT_CONNECT );
    writeDATA( "1,0," );
    writeDATA( GS.portNum );
    writeDATA( "," );
    writeDATA( GS.ipAddress);
    writeDATA( ",0,0,1" );
    NL_TX(1,1);
    CyDelay(50);
    NL_RX();
    msg_clear();
    UART_ClearRxBuffer();
    
    
    UART_PC_PutString("\r\nConnecting to ground station...\r\n");
    
    while ( !(UART_GetRxBufferSize() > 0) );
    memset( recvdMsg , 0 , sizeof(recvdMsg) );
    CyDelay(10);
    NL_RX();
    if( strstr( recvdMsg , "OK" ) )
    {
        UART_PC_PutString("Successfully connected!\r\n");
    }
    else if( strstr( recvdMsg , "ERROR" ) )
    {
        UART_PC_PutString("Connection error. LAME!!!\r\n");
        while(1);
    }
}

void Nimbelink_GSDataXfer( uint8 sckt , char * data )
{
//    NL_scktrecv();
    CyDelay(250);
    NL_scktsend(sckt,data);
}

/* [] END OF FILE */
