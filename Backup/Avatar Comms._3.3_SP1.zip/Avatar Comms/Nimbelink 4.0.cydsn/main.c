/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "nimbelink.h"
#include "L3GD20_I2C.h"

int main()
{
    CyGlobalIntEnable;
    I2C_Start();
    UART_Start();
    UART_PC_Start();
    CyDelay(250);
    
    char message[50];
    
//    Gyro_Start( L3GD20_SENSITIVITY_250DPS );
    
    if( !Gyro_Start( L3GD20_SENSITIVITY_250DPS ) )
    {
        UART_PC_PutString("Gyro failed to start\r\n");
    }
    else
    {
        UART_PC_PutString("Gyro started successfully\r\n");
    }
    
    CyDelay(500);
    
    Nimbelink_Start();
    Nimbelink_ConnectGS("4975","76.240.165.169");
    
//    CyDelay(250);

    for(;;)
    {
        Gyro_Read();
        sprintf( message , "X: %d    Y: %d    Z: %d" , (int)gyro.x , (int)gyro.y , (int)gyro.z );
//        CyDelay(10);
        Nimbelink_GSDataXfer( 1 , message );
        CyDelay(100);
    }
}

/* [] END OF FILE */
